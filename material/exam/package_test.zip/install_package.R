# This code snippet installs the package "modelsummary" without
# requiring access to the internet.

# When run from the command prompt/terminal, 
# the snippet directly installs the package.

# When run manually from within RStudio, you must ensure 
# that your working directory is set to the location of 
# the zip file below.

# There is no need to automate this part of the workflow.

install.packages('svglite_2.1.3.tar', repos=NULL,  type='source')
install.packages('kableExtra_1.4.0.tar', repos=NULL,  type='source')
install.packages('tables_0.9.17.tar', repos=NULL,  type='source')
install.packages('tinytable_0.2.0.tar', repos=NULL,  type='source')
install.packages('modelsummary_1.4.5.tar', repos=NULL,  type='source')
