########################################
### PLOT MONTE VERDE VS MONTE MARIO ####
########################################

df_pivot <- read.csv("../../gen/temp/df_grouped.csv")

# convert the `date` column into date format.
df_pivot$date <- as.Date(df_pivot$date)

pdf("../../gen/output/plot.pdf")
plot(x = df_pivot$date,
     y = df_pivot$`XII Monte Verde`,
     col = "red",
     type = "l",
     xlab = "",
     ylab = "Total number of reviews",
     main = "Effect of COVID-19 pandemic\non Airbnb review count")

lines(df_pivot$date, df_pivot$`XIV Monte Mario`, col="blue")

legend("topleft", c("Monte Verde", "Monte Mario"), fill=c("red", "blue"))
dev.off()