
######################
# CREATE PIVOT TABLE #
######################
library(dplyr)
library(tidyverse)

df_grouped <- read.csv("../../gen/temp/df_grouped.csv")

# create pivot table
df_pivot <- df_grouped %>%
  pivot_wider(
    names_from = neighbourhood,  # Column to spread into multiple columns
    values_from = num_reviews,    # Values to fill in the new columns
    values_fill = list(num_reviews = 0),  # Replace NA with 0 for empty cells
    values_fn = sum  # Aggregate function to sum reviews by neighborhood and date
  )

write.csv(df_pivot, "../../gen/temp/df_pivot.csv", row.names=FALSE)