library(tidyverse)

################################
### SIMULATE SOME DATA DATA ####
################################



# Set seed for reproducibility
set.seed(42)

### SIMULATE LISTINGS DATA ###

# Generate 1000 listings
listings <- data.frame(
  id = 1:1000,  # Listing IDs
  neighbourhood = sample(c("XII Monte Verde", "XIV Monte Mario", "Testaccio", "Trastevere"), 1000, replace = TRUE),
  number_of_reviews = sample(0:100, 1000, replace = TRUE)  # Number of reviews for each listing
)

# Save listings to CSV
write.csv(listings, "../../data/listings.csv", row.names = FALSE)

### SIMULATE REVIEWS DATA ###

# Generate 5000 reviews, ensuring that listing_id matches id from listings
reviews <- data.frame(
  listing_id = sample(listings$id, 5000, replace = TRUE),  # Randomly assign reviews to listings
  date = sample(seq(as.Date('2015-01-01'), as.Date('2023-12-31'), by="day"), 5000, replace = TRUE),  # Random review dates
  reviewer_id = sample(1000:9999, 5000, replace = TRUE),  # Random reviewer IDs
  comments = sample(c("Great place!", "Had a good time.", "Not bad", "Wouldn’t recommend."), 5000, replace = TRUE)
)

# Save reviews to CSV
write.csv(reviews, "../../data/reviews.csv", row.names = FALSE)