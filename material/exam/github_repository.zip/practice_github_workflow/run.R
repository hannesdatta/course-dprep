library(tidyverse)

################################
### SIMULATE SOME DATA DATA ####
################################



# Set seed for reproducibility
set.seed(42)

### SIMULATE LISTINGS DATA ###

# Generate 1000 listings
listings <- data.frame(
  id = 1:1000,  # Listing IDs
  neighbourhood = sample(c("XII Monte Verde", "XIV Monte Mario", "Testaccio", "Trastevere"), 1000, replace = TRUE),
  number_of_reviews = sample(0:100, 1000, replace = TRUE)  # Number of reviews for each listing
)

# Save listings to CSV
write.csv(listings, "listings.csv", row.names = FALSE)

### SIMULATE REVIEWS DATA ###

# Generate 5000 reviews, ensuring that listing_id matches id from listings
reviews <- data.frame(
  listing_id = sample(listings$id, 5000, replace = TRUE),  # Randomly assign reviews to listings
  date = sample(seq(as.Date('2015-01-01'), as.Date('2023-12-31'), by="day"), 5000, replace = TRUE),  # Random review dates
  reviewer_id = sample(1000:9999, 5000, replace = TRUE),  # Random reviewer IDs
  comments = sample(c("Great place!", "Had a good time.", "Not bad", "Wouldn’t recommend."), 5000, replace = TRUE)
)

# Save reviews to CSV
write.csv(reviews, "reviews.csv", row.names = FALSE)

######################
#### CLEAN DATA ######
######################

reviews <- read.csv("reviews.csv")
listings <- read.csv("listings.csv")

# convert date column
reviews$date <- as.Date(reviews$date)

# filter for reviews published since 2016
reviews_filtered <- reviews %>% filter(date > "2016-01-01")

# filter for `listings` that have received at least 1 review.
listings_filtered <- listings %>% filter(number_of_reviews > 1)

# merge the `reviews` and `listings` dataframes on a common columns (the type of join doesn't really matter since we already filtered out listings without any reviews)
df_merged <- reviews_filtered %>%
  inner_join(listings_filtered, by = c("listing_id" = "id"))

# group the number of reviews by month and neighborhood group.
df_grouped <- df_merged %>%
  mutate(month = format(date, "%m"), year = format(date, "%Y")) %>%
  group_by(year, month, neighbourhood) %>%
  summarise(num_reviews = n())

# create date column
df_grouped$date <- as.Date(paste0(df_grouped$year, "-", df_grouped$month, "-01"))

######################
# CREATE PIVOT TABLE #
######################

# create pivot table
df_pivot <- df_grouped %>%
  pivot_wider(
    names_from = neighbourhood,  # Column to spread into multiple columns
    values_from = num_reviews,    # Values to fill in the new columns
    values_fill = list(num_reviews = 0),  # Replace NA with 0 for empty cells
    values_fn = sum  # Aggregate function to sum reviews by neighborhood and date
  )


########################################
### PLOT MONTE VERDE VS MONTE MARIO ####
########################################

# convert the `date` column into date format.
df_pivot$date <- as.Date(df_pivot$date)

pdf("plot.pdf")
plot(x = df_pivot$date,
     y = df_pivot$`XII Monte Verde`,
     col = "red",
     type = "l",
     xlab = "",
     ylab = "Total number of reviews",
     main = "Effect of COVID-19 pandemic\non Airbnb review count")

lines(df_pivot$date, df_pivot$`XIV Monte Mario`, col="blue")

legend("topleft", c("Monte Verde", "Monte Mario"), fill=c("red", "blue"))
dev.off()

######################
##### PLOT ALL #######
######################

# import the data
df <- df_grouped

# convert the `date` column into date format.
df$date <- as.Date(df$date)

# group by date and calculate the sum of all reviews across neighbourhood groups.
df_groupby <- df %>% group_by(date) %>% summarise(num_reviews = sum(num_reviews))

# plot the chart and store the visualisation.

pdf("plot_all.pdf")
plot(x = df_groupby$date,
     y = df_groupby$num_reviews,
     type = "l",
     xlab = "",
     ylab = "Total number of reviews", 
     main = "Effect of COVID-19 pandemic\non Airbnb review count")

dev.off()
