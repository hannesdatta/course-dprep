# Setup block: Load necessary packages
library(tidyverse)
library(broom)
library(ggplot2)

# Load the processed email data
email_data <- read_csv("processed_email_data.csv")

# Check correlation among numeric features
cor_matrix <- email_data %>%
  select(age, days_since_signup, emails_opened, email_engagement_score, total_spent) %>%
  cor()

print("Correlation Matrix:")
print(cor_matrix)

# Logistic regression model to predict conversions
logit_model <- glm(conversions ~ age + days_since_signup + emails_opened + email_engagement_score + total_spent, 
                   data = email_data, family = "binomial")

# Get tidy summary of the model
logit_summary <- tidy(logit_model)
print("Logit Model Summary:")
print(logit_summary)

# Save the model summary
write_csv(logit_summary, "logit_model_summary.csv")

# Predict conversion probabilities
email_data <- email_data %>%
  mutate(predicted_conversion = predict(logit_model, type = "response"))

# Plot conversion probability vs email engagement score
engagement_plot <- ggplot(email_data, aes(x = email_engagement_score, y = predicted_conversion)) +
  geom_point(alpha = 0.6, color = "darkgreen") +
  geom_smooth(method = "lm", color = "blue") +
  labs(title = "Predicted Conversion by Email Engagement Score",
       x = "Email Engagement Score",
       y = "Predicted Conversion Probability") +
  theme_minimal()

# Save the plot
ggsave("conversion_engagement_plot.png", plot = engagement_plot)

# Summary statistics by engagement level
summary_stats <- email_data %>%
  group_by(engagement_level) %>%
  summarise(
    avg_emails_opened = mean(emails_opened, na.rm = TRUE),
    avg_conversion = mean(conversions, na.rm = TRUE),
    avg_total_spent = mean(total_spent, na.rm = TRUE)
  )

print("Summary Statistics by Engagement Level:")
print(summary_stats)

# Save the summary statistics
write_csv(summary_stats, "summary_stats.csv")
