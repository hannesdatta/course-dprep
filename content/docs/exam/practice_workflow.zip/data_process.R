# Setup block: Load necessary packages
library(tidyverse)
library(lubridate)

# Simulate email marketing data
set.seed(42)

# Simulating demographic and email campaign data
email_data <- tibble(
  customer_id = 1:1000,
  age = sample(18:65, 1000, replace = TRUE),
  signup_date = sample(seq(as.Date('2019-01-01'), as.Date('2021-12-31'), by="day"), 1000, replace = TRUE),
  emails_received = rpois(1000, lambda = 20),
  emails_opened = rpois(1000, lambda = 15),
  click_through_rate = runif(1000, min = 0.01, max = 0.3),
  conversions = rbinom(1000, 1, prob = 0.15),
  total_spent = rnorm(1000, mean = 100, sd = 50)
)

# Adding derived features
email_data <- email_data %>%
  mutate(
    email_engagement_score = emails_opened / emails_received,
    days_since_signup = as.numeric(difftime(Sys.Date(), signup_date, units = "days")),
    engagement_level = case_when(
      email_engagement_score >= 0.75 ~ "High",
      email_engagement_score >= 0.5 & email_engagement_score < 0.75 ~ "Medium",
      email_engagement_score >= 0.25 & email_engagement_score < 0.5 ~ "Low",
      TRUE ~ "Very Low"
    ),
    age_group = case_when(
      age < 30 ~ "Young",
      age >= 30 & age <= 50 ~ "Middle-aged",
      age > 50 ~ "Senior"
    )
  )

# Save the processed data
write_csv(email_data, "processed_email_data.csv")
