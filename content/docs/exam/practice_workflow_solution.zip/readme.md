# Overview

This repository contains a simple workflow for analyzing email marketing campaign data. The workflow processes raw email data, performs a statistical analysis, and generates a report with key insights such as model summaries, engagement plots, and summary statistics.

The analysis is written in `R` and is fully automated using a `Makefile`. By running the make command in the `src` directory, the entire process is executed, including data processing, model fitting, and visualization. Final output files are stored in the `output` folder; temporary files are stored in `temp`.